# Handoff: Icares Trainingen — hero + "Ons aanbod" intro

## Overview
The top of the Icares "Trainingen" marketing page: a peach-washed hero with the headline
"Haal het maximale uit Icares", a lead paragraph, two CTAs, three trust items, and two product
cards (Icares Professional / Icares Quest) on the right. A white wave separates the hero from
the next section, which opens with the "Ons aanbod" heading block. Dutch copy throughout.

## About the design files
The files in this bundle are **design references written in HTML** — a prototype of the intended
look, not production code to paste in. Recreate them in the target codebase's own environment
(React/Vue/Astro/WordPress/whatever the site runs on) using its existing components, tokens and
conventions. If no environment exists yet, pick the framework that fits the project and build
there. `hero.html` is a plain standalone page you can open in a browser; the `.dc.html` file is
the authoring source and is included only for reference.

## Fidelity
**High fidelity.** Colors, type sizes, spacing and radii below are final and should be matched.
The design was authored on a fixed 1856px canvas (matching the supplied reference screenshot);
production should reflow it — see Responsive behavior.

## Screens / views

### 1. Hero (height 700px on the 1856px canvas)
**Purpose:** state the offer and route visitors to either the trainings overview or contact.

**Layout**
- Full-bleed section, `position: relative; overflow: hidden`.
- Background: `linear-gradient(160deg, #FFF8F2 0%, #FEFCFA 45%, #FDFAF7 100%)`.
- Content grid: two columns `714px | 696px`, no gap, `padding: 96px 0 0 230px`
  (230px = left page gutter on the 1856px canvas; in production use the site container).
- Decorative layer (all absolutely positioned, non-interactive, `aria-hidden`):
  - large peach radial blob top-right: 900×820, `top:-340 right:-260`,
    `radial-gradient(circle at 35% 65%, #F9C08A 0%, #FBD5AE 45%, rgba(253,240,226,0) 72%)`, opacity .85
  - solid peach circle 420×420, `top:-120 right:-40`, `#F7B274`, opacity .35, `blur(2px)`
  - thin curved stroke, right side: `#F5A05A`, 2px, opacity .55
  - three soft cream/peach circles on the left: 180×180 `#FBDCBE` (.5), 280×280 `#FCE7D3` (.55),
    520×460 `#FBE3CC` (.45)
  - dot grid: 6×6 dots, 5px round, `#F7B57A`, 16px columns, 14px gap, at `top:128 left:22`
  - bottom wave: full-width SVG, height 82px, `bottom:-1`, fill `#FFFFFF`,
    path `M0 74C240 26 560 6 928 22C1296 38 1620 74 1856 44V112H0Z` (viewBox `0 0 1856 110`,
    `preserveAspectRatio="none"`)

**Left column (max-width 660px)**
| Element | Spec | Copy |
| --- | --- | --- |
| Overline | 15px / 600 / `letter-spacing .17em` / uppercase / `#F5811F` | Trainingen |
| H1 | 72px / 800 / line-height 1.06 / `letter-spacing -.018em` / `#16264A`; accent word `#F5811F`; margin-top 14px | Haal het maximale<br>uit **Icares** |
| Lead | 21px / 400 / line-height 1.55 / `#5A6472`; max-width 648px; margin-top 30px | Met onze trainingen voor Icares Professional en Icares Quest effectief inzetten in de begeleiding van leerlingen, studenten en cliënten. Praktisch, concreet en direct toepasbaar. |
| Button row | flex, gap 22px, margin-top 38px | |
| Primary CTA | height 56px, padding 0 30px, radius 10px, bg `#F5811F`, text `#fff` 18px/700, gap 14px to a 20px arrow icon, shadow `0 10px 22px rgba(245,129,31,.28)` | Bekijk de trainingen → |
| Secondary CTA | height 56px, padding 0 30px, radius 10px, bg `#fff`, border `2px solid #F5811F`, text `#F5811F` 18px/700 | Neem contact op |
| Trust row | flex, gap 64px, margin-top 44px | |
| Trust item | 46px circle `#FCE7D2` + 22px line icon `#F5811F`, gap 14px; title 16px/700 `#16264A`; sub 15px `#7C8593` (margin-top 2px) | "Ervaren trainers / Uit de praktijk", "Direct toepasbaar / Concrete handvatten", "Voor onderwijs en professionals" (two lines, no sub, line-height 1.35) |

**Right column (696px) — two product cards, stacked, gap 22px**
- Card: bg `#fff`, radius 16px, padding `28px 32px 26px`, shadow `0 8px 28px rgba(23,38,74,.07)`,
  grid `72px | 1fr`, gap 22px, items start.
- Icon: 64px circle `#FCE7D2`, 30px line icon `#F5811F`, margin-top 4px.
- Title row: flex, space-between, gap 20px. Title 23px/700 `#16264A`, line-height 1.2.
- Badge: pill, bg `#FCE7D2`, text `#E0771A` 11px/700, `letter-spacing .07em`, uppercase,
  padding `6px 12px`, margin-top 3px.
- Body: 17px / line-height 1.5 / `#5A6472`, margin-top 12px.
- Link: 17px/700 `#F5811F`, inline-flex, gap 10px, 18px arrow icon, margin-top 20px.

| Card | Icon | Badge | Title | Body | Link |
| --- | --- | --- | --- | --- | --- |
| 1 | user in circle | VOOR PROFESSIONALS | Icares Professional | De belangrijkste modules en functies van Icares Professional. Geschikt voor re-integratiebegeleiders, jobcoaches en onderwijsprofessionals die het maximale uit de tool willen halen. | Meer over Icares Professional → |
| 2 | open book | VOOR SCHOLEN | Icares Quest | Het LOB-instrument voor het voortgezet onderwijs. In deze training leer je Quest slim in te zetten in je mentorlessen en LOB-programma's. | Meer over Icares Quest → |

**Handwritten note** (decorative, bottom-right of the card column): "Samen meer impact maken",
Caveat 600 30px `#F5811F`, width 200px, `rotate(-7deg)`, with a hand-drawn underline swoosh
(SVG path `M3 15C34 5 120 2 166 14`, stroke `#F5811F` 2.6px, round cap), 150×20, offset 26px left.
Positioned `right: 120px; bottom: -104px` relative to the card column.

### 2. "Ons aanbod" section opener
White background, centered, `padding: 0 0 56px` (it sits directly under the hero wave).
| Element | Spec | Copy |
| --- | --- | --- |
| Overline | 15px / 600 / `.17em` / uppercase / `#F5811F` | Ons aanbod |
| H2 | 46px / 800 / `-.018em` / `#16264A`, margin-top 12px | Kies de training die bij je past |
| Sub | 20px / line-height 1.5 / `#5A6472`, max-width 660px, centered, margin-top 18px | Bij jou op locatie, samen met anderen in Eindhoven of speciaal voor het onderwijs. |

Stacking note: the wave belongs to the hero and must paint **below** this block. Keep it as the
hero's last child; do not move it into the section, or it will cover the heading.

## Interactions & behavior
- Primary CTA hover: `filter: brightness(.96)`; optional 2px lift.
- Secondary CTA hover: fill `#FEF1E4`, border and text unchanged.
- Card links hover: darken to `#D96A0C`.
- Cards are static in this design (no hover lift specified); add `translateY(-2px)` +
  `0 12px 32px rgba(23,38,74,.10)` over 240ms if the site's cards do that elsewhere.
- Transitions: 160ms `cubic-bezier(.4,0,.2,1)` for color/hover, 240ms for lift.
- No animation on load. Respect `prefers-reduced-motion`.
- Decorative blobs, dot grid, wave and handwritten note are `aria-hidden`; the icons are decorative
  too (titles carry the meaning).

## State management
None. Static marketing markup; the two CTAs and two card links are plain anchors
(targets: trainings overview and contact page; card links to the two product/training pages).

## Design tokens
**Color**
| Token | Hex | Use |
| --- | --- | --- |
| orange-500 | `#F5811F` | accent word, CTA fill, links, overline |
| orange-600 | `#E0771A` | badge text |
| orange-700 | `#D96A0C` | link hover |
| orange-100 | `#FCE7D2` | icon discs, badges |
| orange-050 | `#FEF1E4` | secondary button hover |
| peach tints | `#F9C08A` `#FBD5AE` `#F7B274` `#FBDCBE` `#FCE7D3` `#FBE3CC` `#F7B57A` `#F5A05A` | decorative shapes |
| cream wash | `#FFF8F2` → `#FEFCFA` → `#FDFAF7` | hero background |
| navy-900 | `#16264A` | headings, strong labels |
| grey-600 | `#5A6472` | body text |
| grey-500 | `#7C8593` | trust sub-labels |
| white | `#FFFFFF` | cards, wave, section below |

**Type** — Figtree (400/600/700/800) for everything; Caveat 600 for the handwritten note only.
Scale: 72 / 46 / 23 / 21 / 20 / 18 / 17 / 16 / 15 / 11 px. Line heights 1.06 (H1), 1.2 (card title),
1.5 (card/section body), 1.55 (lead). Tracking −.018em on display, .17em on overlines, .07em on badges.

**Spacing** — 2 / 4 / 10 / 12 / 14 / 18 / 20 / 22 / 26 / 28 / 30 / 32 / 38 / 44 / 64 / 96 px.
**Radius** — 10px buttons, 16px cards, 999px badges, 50% icon discs.
**Shadow** — card `0 8px 28px rgba(23,38,74,.07)`; primary CTA `0 10px 22px rgba(245,129,31,.28)`.

## Responsive behavior
Not designed; the prototype is a fixed 1856px canvas. Suggested production rules:
- Container max-width ~1400px with 24px gutters; drop the 230px hard left padding.
- Below ~1100px: stack the two columns (text first, cards below), reduce H1 to ~clamp(40px, 6vw, 72px).
- Below ~700px: trust row wraps to a column, CTAs full-width, card icon column collapses to a
  48px disc above the title, hide the handwritten note and the left dot grid.

## Assets
No bitmaps. All decoration is CSS shapes and inline SVG. Icons are Lucide-style line icons
(`users`, `graduation-cap`, `bar-chart`, `circle-user`, `book-open`, `arrow-right`) at
stroke-width 1.8–2.2, `currentColor` — swap for the codebase's icon set. Fonts load from Google
Fonts (Figtree, Caveat); Figtree stands in for the brand display face — replace with the licensed
Icares/Croogla webfont if available. Reference screenshot the design was matched against was
supplied by the client.

## Files
- `hero.html` — standalone HTML of the full design (open directly in a browser).
- `Icares Trainingen Hero.dc.html` — authoring source; same markup, reference only.
